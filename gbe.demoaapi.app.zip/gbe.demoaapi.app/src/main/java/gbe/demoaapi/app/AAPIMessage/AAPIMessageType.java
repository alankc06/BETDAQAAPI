package gbe.demoaapi.app.AAPIMessage;

public enum AAPIMessageType {
    INITIAL_TOPIC_LOAD, DELTA, DELETE
}

